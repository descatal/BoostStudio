import{h as e}from"./index-_vJHe0oM.js";const o=e("X",[["path",{d:"M18 6 6 18",key:"1bl5f8"}],["path",{d:"m6 6 12 12",key:"d8bk6v"}]]);export{o as X};
