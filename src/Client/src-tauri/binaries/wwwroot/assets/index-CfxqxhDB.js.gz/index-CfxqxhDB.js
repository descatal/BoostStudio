import{j as t,N as n}from"./index-_vJHe0oM.js";const p=function(){return t.jsx(n,{to:"/units",replace:!0})};export{p as component};
