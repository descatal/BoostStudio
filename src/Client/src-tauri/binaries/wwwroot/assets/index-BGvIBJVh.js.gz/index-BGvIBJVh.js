import{j as t,N as o}from"./index-_vJHe0oM.js";const s=function(){return t.jsx(o,{to:"/units/info/stats",replace:!0})};export{s as component};
