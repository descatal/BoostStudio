import"./index-_vJHe0oM.js";import{L as o}from"./loader-2-BZ5HxNZN.js";const n={spinner:o};export{n as I};
