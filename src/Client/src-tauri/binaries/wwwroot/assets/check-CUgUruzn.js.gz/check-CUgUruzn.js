import{h as e}from"./index-_vJHe0oM.js";const c=e("Check",[["polyline",{points:"20 6 9 17 4 12",key:"10jjfj"}]]);export{c as C};
