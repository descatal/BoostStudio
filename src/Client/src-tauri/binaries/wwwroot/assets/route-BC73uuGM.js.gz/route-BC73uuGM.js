import{u as s,r as e,j as n,O as p}from"./index-_vJHe0oM.js";const u=function(){const t=s(o=>o.setTopbarLinks);return e.useEffect(()=>{t([])},[]),n.jsx(p,{})};export{u as component};
