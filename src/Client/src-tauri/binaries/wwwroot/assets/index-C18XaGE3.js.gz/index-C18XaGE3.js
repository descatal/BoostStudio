import{j as o,N as t}from"./index-_vJHe0oM.js";const p=function(){return o.jsx(t,{to:"/tools/fhm",replace:!0})};export{p as component};
